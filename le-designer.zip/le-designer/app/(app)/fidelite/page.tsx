"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { useRouter } from "next/navigation";
import { apiFetch } from "@/lib/telegram-client";
import { useTelegramBackButton } from "@/lib/use-telegram-back-button";
import { LoyaltyCard } from "@/components/loyalty/LoyaltyCard";
import { Character3D } from "@/components/character/Character";
import { BottomNav } from "@/components/navigation/BottomNav";

const ERROR_MESSAGES: Record<string, string> = {
  code_not_found: "Ce code n'existe pas.",
  code_already_used: "Ce code a déjà été utilisé.",
  invalid_code_format: "Format de code invalide.",
  user_not_found: "Profil introuvable, réouvre l'app depuis Telegram.",
};

export default function FidelitePage() {
  const router = useRouter();
  const [progress, setProgress] = useState(0);
  const [loading, setLoading] = useState(true);
  const [showInput, setShowInput] = useState(false);
  const [code, setCode] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [feedback, setFeedback] = useState<{ type: "success" | "error"; text: string } | null>(
    null
  );
  const [celebrate, setCelebrate] = useState(false);

  useTelegramBackButton(() => router.push("/accueil"));

  useEffect(() => {
    loadStatus();
    apiFetch("/api/analytics/event", {
      method: "POST",
      body: JSON.stringify({ event_type: "loyalty_open" }),
    });
  }, []);

  async function loadStatus() {
    setLoading(true);
    try {
      const res = await apiFetch("/api/loyalty/status");
      if (res.ok) {
        const data = await res.json();
        setProgress(data.loyalty_progress);
      }
    } finally {
      setLoading(false);
    }
  }

  async function submitCode() {
    if (!code.trim() || submitting) return;
    setSubmitting(true);
    setFeedback(null);
    try {
      const res = await apiFetch("/api/loyalty/use-code", {
        method: "POST",
        body: JSON.stringify({ code: code.trim() }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setProgress(data.loyalty_progress);
        setFeedback({ type: "success", text: "Code validé ! Case ajoutée à ta carte." });
        setCode("");
        setShowInput(false);
        if (data.gift_unlocked) {
          setCelebrate(true); // déclenche l'apparition du personnage pour le cadeau
        }
      } else {
        setFeedback({
          type: "error",
          text: ERROR_MESSAGES[data.error] ?? "Une erreur est survenue.",
        });
      }
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="min-h-screen pb-24 px-5 pt-8">
      <header className="text-center mb-6">
        <h1 className="text-2xl font-display font-bold">Fidélité</h1>
        <p className="text-white/50 text-sm mt-1">10 commandes = 1 cadeau offert</p>
      </header>

      {celebrate && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 bg-background/90 flex flex-col items-center justify-center gap-4 px-6"
          onClick={() => setCelebrate(false)}
        >
          <motion.div
            initial={{ scale: 0.7, y: 20 }}
            animate={{ scale: 1, y: 0 }}
            transition={{ type: "spring", stiffness: 180, damping: 14 }}
          >
            <Character3D />
          </motion.div>
          <p className="text-gold font-display font-bold text-xl text-center">
            🎁 Bravo, ton cadeau est débloqué !
          </p>
          <button
            onClick={() => setCelebrate(false)}
            className="mt-2 px-8 py-3 rounded-full bg-accent text-background font-semibold"
          >
            Super !
          </button>
        </motion.div>
      )}

      {loading ? (
        <div className="text-center text-white/40 text-sm py-10">Chargement…</div>
      ) : (
        <>
          <LoyaltyCard progress={progress} />

          <div className="mt-6">
            {!showInput ? (
              <button
                onClick={() => setShowInput(true)}
                className="w-full py-3.5 rounded-full bg-accent text-background font-display font-bold"
              >
                UTILISER UN CODE
              </button>
            ) : (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="glass-card rounded-xl2 p-4 space-y-3"
              >
                <label className="text-xs text-white/50">Entrez votre code secret</label>
                <input
                  autoFocus
                  value={code}
                  onChange={(e) => setCode(e.target.value.toUpperCase())}
                  placeholder="LD-8F4K-X9Z"
                  className="w-full bg-surfaceAlt rounded-lg px-4 py-3 text-center tracking-widest font-mono outline-none"
                />
                <div className="flex gap-2">
                  <button
                    onClick={() => setShowInput(false)}
                    className="flex-1 py-3 rounded-full border border-white/15 text-white/60"
                  >
                    Annuler
                  </button>
                  <button
                    onClick={submitCode}
                    disabled={submitting || !code.trim()}
                    className="flex-1 py-3 rounded-full bg-accent text-background font-semibold disabled:opacity-40"
                  >
                    {submitting ? "Vérification…" : "Valider"}
                  </button>
                </div>
              </motion.div>
            )}

            {feedback && (
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className={`text-center text-sm mt-3 ${
                  feedback.type === "success" ? "text-accent" : "text-red-400"
                }`}
              >
                {feedback.text}
              </motion.p>
            )}
          </div>
        </>
      )}

      <BottomNav />
    </div>
  );
}
