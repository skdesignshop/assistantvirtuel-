"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { apiFetch } from "@/lib/telegram-client";
import { useTelegramBackButton } from "@/lib/use-telegram-back-button";
import { Globe3D } from "@/components/globe/Globe3D";
import { BottomNav } from "@/components/navigation/BottomNav";
import type { City, Testimonial } from "@/types";

export default function VillesPage() {
  const router = useRouter();
  const [cities, setCities] = useState<City[]>([]);
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);
  const [selectedCity, setSelectedCity] = useState<City | null>(null);
  const [loading, setLoading] = useState(true);

  useTelegramBackButton(() => router.push("/accueil"));

  useEffect(() => {
    load();
    apiFetch("/api/analytics/event", {
      method: "POST",
      body: JSON.stringify({ event_type: "page_view", metadata: { page: "villes" } }),
    });
  }, []);

  async function load() {
    setLoading(true);
    try {
      const [citiesRes, testimonialsRes] = await Promise.all([
        fetch("/api/cities"),
        fetch("/api/testimonials"),
      ]);
      const citiesData = await citiesRes.json();
      const testimonialsData = await testimonialsRes.json();
      setCities(citiesData.cities ?? []);
      setTestimonials(testimonialsData.testimonials ?? []);
    } finally {
      setLoading(false);
    }
  }

  function handleSelectCity(city: City) {
    setSelectedCity(city);
    apiFetch("/api/analytics/event", {
      method: "POST",
      body: JSON.stringify({ event_type: "city_view", metadata: { city: city.name } }),
    });
  }

  return (
    <div className="min-h-screen pb-24">
      <header className="px-5 pt-8 pb-4 text-center">
        <p className="text-xs tracking-widest text-accent uppercase">LE DESIGNER</p>
        <h1 className="text-2xl font-display font-bold mt-1">Nos villes</h1>
        <p className="text-white/50 text-sm mt-1">Fais tourner le globe et découvre-nous</p>
      </header>

      {loading ? (
        <div className="h-72 flex items-center justify-center text-white/40 text-sm">
          Chargement du globe…
        </div>
      ) : (
        <Globe3D cities={cities} onSelectCity={handleSelectCity} />
      )}

      <AnimatePresence>
        {selectedCity && (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 30 }}
            className="mx-5 mt-2 glass-card rounded-xl2 p-4 flex gap-3 items-center"
          >
            {selectedCity.logo_url ? (
              <Image
                src={selectedCity.logo_url}
                alt={selectedCity.name}
                width={48}
                height={48}
                className="rounded-full"
              />
            ) : (
              <div className="w-12 h-12 rounded-full bg-accent/20 flex items-center justify-center text-lg">
                📍
              </div>
            )}
            <div className="flex-1">
              <p className="font-semibold">{selectedCity.name}</p>
              {selectedCity.description && (
                <p className="text-white/50 text-xs mt-0.5">{selectedCity.description}</p>
              )}
            </div>
            <button onClick={() => setSelectedCity(null)} className="text-white/40 px-2">
              ✕
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      <section className="mt-10 px-5">
        <h2 className="font-display font-bold text-lg mb-4">Ils nous font confiance</h2>

        {testimonials.length === 0 ? (
          <p className="text-white/40 text-sm">Aucun avis à afficher pour le moment.</p>
        ) : (
          <div className="flex gap-3 overflow-x-auto pb-2 -mx-5 px-5 snap-x snap-mandatory">
            {testimonials.map((t) => (
              <div
                key={t.id}
                className="glass-card rounded-xl2 p-4 min-w-[240px] snap-start flex-shrink-0"
              >
                <div className="flex items-center gap-2 mb-2">
                  {t.photo_url ? (
                    <Image
                      src={t.photo_url}
                      alt={t.name}
                      width={32}
                      height={32}
                      className="rounded-full"
                    />
                  ) : (
                    <div className="w-8 h-8 rounded-full bg-violet/30" />
                  )}
                  <div>
                    <p className="text-sm font-semibold leading-none">{t.name}</p>
                    {t.city && <p className="text-[11px] text-white/40">{t.city}</p>}
                  </div>
                </div>
                {t.rating && (
                  <p className="text-gold text-xs mb-1">{"★".repeat(t.rating)}</p>
                )}
                <p className="text-sm text-white/70 leading-relaxed">{t.message}</p>
              </div>
            ))}
          </div>
        )}
      </section>

      <BottomNav />
    </div>
  );
}
