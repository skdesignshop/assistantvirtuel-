"use client";

import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import Image from "next/image";
import { useAppUser } from "@/components/UserProvider";
import { useHideTelegramBackButton } from "@/lib/use-telegram-back-button";
import { Character3D } from "@/components/character/Character";

export default function AccueilPage() {
  const { user, loading, error, refresh } = useAppUser();
  const router = useRouter();

  useHideTelegramBackButton();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <motion.div
          className="w-10 h-10 rounded-full border-2 border-accent border-t-transparent"
          animate={{ rotate: 360 }}
          transition={{ repeat: Infinity, duration: 0.8, ease: "linear" }}
        />
      </div>
    );
  }

  if (error || !user) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center px-6 text-center gap-4">
        <p className="text-white/70">
          Impossible de vérifier ton identité Telegram. Ouvre cette page depuis la Mini App Telegram.
        </p>
        <button
          onClick={refresh}
          className="px-6 py-3 rounded-full bg-accent text-background font-semibold"
        >
          Réessayer
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-6 py-10 gap-8 relative overflow-hidden">
      {/* Fond dégradé premium */}
      <div className="absolute inset-0 bg-gradient-to-b from-surface via-background to-background -z-10" />
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-72 h-72 bg-accent/10 rounded-full blur-3xl -z-10" />

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
      >
        <Character3D />
      </motion.div>

      <AnimatePresence>
        <motion.div
          className="text-center space-y-3"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.6 }}
        >
          <p className="text-sm tracking-widest text-accent uppercase">Bienvenue</p>
          <h1 className="text-3xl md:text-4xl font-display font-bold">
            {user.first_name.toUpperCase()}
          </h1>

          <div className="flex items-center justify-center gap-2 pt-2">
            {user.photo_url && (
              <Image
                src={user.photo_url}
                alt={user.first_name}
                width={36}
                height={36}
                className="rounded-full border border-white/10"
              />
            )}
            {user.username && <span className="text-white/50 text-sm">@{user.username}</span>}
          </div>
        </motion.div>
      </AnimatePresence>

      <motion.button
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1, duration: 0.6 }}
        onClick={() => router.push("/assistant")}
        className="mt-4 px-10 py-4 rounded-full bg-accent text-background font-display font-bold tracking-wide shadow-premium active:scale-95 transition-transform"
      >
        ENTRER
      </motion.button>
    </div>
  );
}
