"use client";

import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { useRouter } from "next/navigation";
import { apiFetch } from "@/lib/telegram-client";
import { useTelegramBackButton } from "@/lib/use-telegram-back-button";
import { Character3D } from "@/components/character/Character";
import { BottomNav } from "@/components/navigation/BottomNav";

interface ChatMsg {
  id: string;
  role: "user" | "assistant";
  content: string;
}

export default function AssistantPage() {
  const router = useRouter();
  const [messages, setMessages] = useState<ChatMsg[]>([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [loadingHistory, setLoadingHistory] = useState(true);
  const scrollRef = useRef<HTMLDivElement>(null);

  useTelegramBackButton(() => router.push("/accueil"));

  useEffect(() => {
    loadHistory();
    apiFetch("/api/analytics/event", {
      method: "POST",
      body: JSON.stringify({ event_type: "assistant_open" }),
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, sending]);

  async function loadHistory() {
    setLoadingHistory(true);
    try {
      const res = await apiFetch("/api/assistant/chat");
      if (res.ok) {
        const data = await res.json();
        setMessages(data.messages ?? []);
      }
    } finally {
      setLoadingHistory(false);
    }
  }

  async function sendMessage() {
    const text = input.trim();
    if (!text || sending) return;

    setInput("");
    const tempId = `local-${Date.now()}`;
    setMessages((prev) => [...prev, { id: tempId, role: "user", content: text }]);
    setSending(true);

    try {
      const res = await apiFetch("/api/assistant/chat", {
        method: "POST",
        body: JSON.stringify({ message: text }),
      });
      const data = await res.json();
      if (res.ok) {
        setMessages((prev) => [
          ...prev,
          { id: `${tempId}-reply`, role: "assistant", content: data.reply },
        ]);
      } else {
        setMessages((prev) => [
          ...prev,
          {
            id: `${tempId}-error`,
            role: "assistant",
            content: "L'assistant n'est pas disponible pour le moment. Réessaie dans un instant.",
          },
        ]);
      }
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="min-h-screen flex flex-col pb-24">
      <header className="flex items-center gap-3 px-4 py-4 glass-card sticky top-0 z-10 border-b border-white/5">
        <button onClick={() => router.push("/accueil")} className="text-white/60 text-xl">
          ←
        </button>
        <div className="w-10 h-10 -my-2">
          <Character3D animated={false} />
        </div>
        <div>
          <p className="font-display font-semibold leading-none">Assistant LE DESIGNER</p>
          <p className="text-xs text-accent">En ligne</p>
        </div>
      </header>

      <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 py-4 space-y-3">
        {loadingHistory && (
          <p className="text-center text-white/40 text-sm">Chargement de la conversation…</p>
        )}

        {!loadingHistory && messages.length === 0 && (
          <div className="text-center text-white/50 text-sm mt-10">
            Pose ta question sur nos services, tarifs ou délais 👋
          </div>
        )}

        {messages.map((m) => (
          <motion.div
            key={m.id}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            className={`max-w-[80%] px-4 py-2.5 rounded-2xl text-sm leading-relaxed ${
              m.role === "user"
                ? "ml-auto bg-accent text-background rounded-br-sm"
                : "mr-auto glass-card rounded-bl-sm"
            }`}
          >
            {m.content}
          </motion.div>
        ))}

        {sending && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="mr-auto glass-card px-4 py-2.5 rounded-2xl rounded-bl-sm text-sm text-white/50"
          >
            l&apos;assistant écrit…
          </motion.div>
        )}
      </div>

      <div className="fixed bottom-16 inset-x-0 px-4 py-3 glass-card border-t border-white/5">
        <div className="flex items-center gap-2 max-w-md mx-auto">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && sendMessage()}
            placeholder="Écris ton message…"
            className="flex-1 bg-surfaceAlt rounded-full px-4 py-2.5 text-sm outline-none placeholder:text-white/30"
          />
          <button
            onClick={sendMessage}
            disabled={sending || !input.trim()}
            className="w-10 h-10 rounded-full bg-accent text-background flex items-center justify-center disabled:opacity-40"
          >
            ➤
          </button>
        </div>
      </div>

      <BottomNav />
    </div>
  );
}
