import { NextResponse } from "next/server";
import { supabaseServer } from "@/lib/supabase-server";

export const runtime = "nodejs";

// Route publique en lecture seule : uniquement les villes marquées visible=true
export async function GET() {
  const supabase = supabaseServer();
  const { data, error } = await supabase
    .from("cities")
    .select("id, name, country, latitude, longitude, logo_url, image_url, description, link")
    .eq("visible", true)
    .order("name", { ascending: true });

  if (error) return NextResponse.json({ error: "db_error" }, { status: 500 });
  return NextResponse.json({ cities: data });
}
