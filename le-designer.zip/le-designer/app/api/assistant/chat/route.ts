import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { verifyRequestAuth } from "@/lib/telegram-auth";
import { supabaseServer } from "@/lib/supabase-server";
import { getAssistantReply, getSystemPrompt } from "@/lib/ai-provider";

export const runtime = "nodejs";

const bodySchema = z.object({
  message: z.string().min(1).max(4000),
});

export async function POST(req: NextRequest) {
  const initDataHeader = req.headers.get("x-telegram-init-data");
  const verified = verifyRequestAuth(initDataHeader);
  if (!verified) {
    return NextResponse.json({ error: "invalid_telegram_signature" }, { status: 401 });
  }

  const json = await req.json().catch(() => null);
  const parsed = bodySchema.safeParse(json);
  if (!parsed.success) {
    return NextResponse.json({ error: "invalid_message" }, { status: 400 });
  }

  const telegramId = verified.user.id;
  const supabase = supabaseServer();

  // Enregistre le message utilisateur
  await supabase.from("messages").insert({
    telegram_user_id: telegramId,
    role: "user",
    content: parsed.data.message,
  });

  await supabase.from("app_events").insert({
    telegram_user_id: telegramId,
    event_type: "message_sent",
    metadata: {},
  });

  // Récupère les 20 derniers messages pour donner du contexte à l'IA
  const { data: recentMessages } = await supabase
    .from("messages")
    .select("role, content")
    .eq("telegram_user_id", telegramId)
    .order("created_at", { ascending: false })
    .limit(20);

  const history = (recentMessages ?? []).reverse().map((m) => ({
    role: m.role as "user" | "assistant",
    content: m.content,
  }));

  let replyText: string;
  try {
    replyText = await getAssistantReply(history, getSystemPrompt());
  } catch (err) {
    console.error("Erreur assistant IA:", err);
    return NextResponse.json(
      { error: "ai_unavailable" },
      { status: 503 }
    );
  }

  await supabase.from("messages").insert({
    telegram_user_id: telegramId,
    role: "assistant",
    content: replyText,
  });

  return NextResponse.json({ reply: replyText });
}

// Récupère l'historique complet de conversation
export async function GET(req: NextRequest) {
  const initDataHeader = req.headers.get("x-telegram-init-data");
  const verified = verifyRequestAuth(initDataHeader);
  if (!verified) {
    return NextResponse.json({ error: "invalid_telegram_signature" }, { status: 401 });
  }

  const supabase = supabaseServer();
  const { data, error } = await supabase
    .from("messages")
    .select("id, role, content, created_at")
    .eq("telegram_user_id", verified.user.id)
    .order("created_at", { ascending: true })
    .limit(100);

  if (error) return NextResponse.json({ error: "db_error" }, { status: 500 });
  return NextResponse.json({ messages: data });
}
