import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { verifyRequestAuth } from "@/lib/telegram-auth";
import { supabaseServer } from "@/lib/supabase-server";

export const runtime = "nodejs";

const VALID_EVENTS = [
  "page_view",
  "assistant_open",
  "loyalty_open",
  "city_view",
  "testimonial_view",
] as const;

const bodySchema = z.object({
  event_type: z.enum(VALID_EVENTS),
  metadata: z.record(z.unknown()).optional(),
});

export async function POST(req: NextRequest) {
  const initDataHeader = req.headers.get("x-telegram-init-data");
  const verified = verifyRequestAuth(initDataHeader);
  // Les événements anonymes (avant auth complète) sont tolérés mais sans telegram_id
  const telegramId = verified?.user.id ?? null;

  const json = await req.json().catch(() => null);
  const parsed = bodySchema.safeParse(json);
  if (!parsed.success) {
    return NextResponse.json({ error: "invalid_body" }, { status: 400 });
  }

  const supabase = supabaseServer();
  await supabase.from("app_events").insert({
    telegram_user_id: telegramId,
    event_type: parsed.data.event_type,
    metadata: parsed.data.metadata ?? {},
  });

  return NextResponse.json({ success: true });
}
