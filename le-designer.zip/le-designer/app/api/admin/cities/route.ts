import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { requireAdmin } from "@/lib/require-admin";
import { supabaseServer } from "@/lib/supabase-server";

export const runtime = "nodejs";

const citySchema = z.object({
  id: z.string().uuid().optional(),
  name: z.string().min(1).max(120),
  country: z.string().min(1).max(80).default("France"),
  latitude: z.number().min(-90).max(90),
  longitude: z.number().min(-180).max(180),
  logo_url: z.string().url().nullable().optional(),
  image_url: z.string().url().nullable().optional(),
  description: z.string().max(2000).nullable().optional(),
  link: z.string().url().nullable().optional(),
  visible: z.boolean().default(true),
});

// GET: liste complète (visibles + masquées) pour l'admin
export async function GET(req: NextRequest) {
  const admin = requireAdmin(req);
  if (!admin.ok) return admin.response;

  const supabase = supabaseServer();
  const { data, error } = await supabase
    .from("cities")
    .select("*")
    .order("name", { ascending: true });

  if (error) return NextResponse.json({ error: "db_error" }, { status: 500 });
  return NextResponse.json({ cities: data });
}

// POST: créer une ville
export async function POST(req: NextRequest) {
  const admin = requireAdmin(req);
  if (!admin.ok) return admin.response;

  const json = await req.json().catch(() => null);
  const parsed = citySchema.omit({ id: true }).safeParse(json);
  if (!parsed.success) {
    return NextResponse.json({ error: "invalid_body", details: parsed.error.flatten() }, { status: 400 });
  }

  const supabase = supabaseServer();
  const { data, error } = await supabase.from("cities").insert(parsed.data).select("*").single();

  if (error) return NextResponse.json({ error: "db_error" }, { status: 500 });
  return NextResponse.json({ city: data });
}

// PATCH: modifier une ville (id requis dans le body)
export async function PATCH(req: NextRequest) {
  const admin = requireAdmin(req);
  if (!admin.ok) return admin.response;

  const json = await req.json().catch(() => null);
  const parsed = citySchema.partial().extend({ id: z.string().uuid() }).safeParse(json);
  if (!parsed.success) {
    return NextResponse.json({ error: "invalid_body", details: parsed.error.flatten() }, { status: 400 });
  }

  const { id, ...updates } = parsed.data;
  const supabase = supabaseServer();
  const { data, error } = await supabase.from("cities").update(updates).eq("id", id).select("*").single();

  if (error) return NextResponse.json({ error: "db_error" }, { status: 500 });
  return NextResponse.json({ city: data });
}

// DELETE: supprimer une ville (?id=uuid)
export async function DELETE(req: NextRequest) {
  const admin = requireAdmin(req);
  if (!admin.ok) return admin.response;

  const id = req.nextUrl.searchParams.get("id");
  if (!id) return NextResponse.json({ error: "missing_id" }, { status: 400 });

  const supabase = supabaseServer();
  const { error } = await supabase.from("cities").delete().eq("id", id);

  if (error) return NextResponse.json({ error: "db_error" }, { status: 500 });
  return NextResponse.json({ success: true });
}
