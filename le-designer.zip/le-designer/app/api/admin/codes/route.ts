import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/require-admin";
import { supabaseServer } from "@/lib/supabase-server";

export const runtime = "nodejs";

export async function GET(req: NextRequest) {
  const admin = requireAdmin(req);
  if (!admin.ok) return admin.response;

  const supabase = supabaseServer();
  const searchParams = req.nextUrl.searchParams;
  const status = searchParams.get("status"); // "used" | "available" | null (tous)

  let query = supabase
    .from("loyalty_codes")
    .select(
      "id, code, used, used_at, created_at, used_by:users(id, first_name, username, telegram_id)"
    )
    .order("created_at", { ascending: false })
    .limit(500);

  if (status === "used") query = query.eq("used", true);
  if (status === "available") query = query.eq("used", false);

  const { data, error } = await query;

  if (error) {
    return NextResponse.json({ error: "db_error" }, { status: 500 });
  }

  return NextResponse.json({ codes: data });
}
