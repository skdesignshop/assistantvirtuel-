import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { customAlphabet } from "nanoid";
import { requireAdmin } from "@/lib/require-admin";
import { supabaseServer } from "@/lib/supabase-server";

export const runtime = "nodejs";

// Alphabet sans caractères ambigus (pas de 0/O, 1/I) pour des codes lisibles à la main
const ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
const nanoid = customAlphabet(ALPHABET, 4);

function generateCode(): string {
  // Format LD-XXXX-XXX, ex: LD-8F4K-X9Z
  const part1 = nanoid();
  const part2 = customAlphabet(ALPHABET, 3)();
  return `LD-${part1}-${part2}`;
}

const bodySchema = z.object({
  count: z.number().int().min(1).max(100),
});

export async function POST(req: NextRequest) {
  const admin = requireAdmin(req);
  if (!admin.ok) return admin.response;

  const json = await req.json().catch(() => null);
  const parsed = bodySchema.safeParse(json);
  if (!parsed.success) {
    return NextResponse.json({ error: "invalid_count" }, { status: 400 });
  }

  const supabase = supabaseServer();
  const codes = new Set<string>();
  while (codes.size < parsed.data.count) {
    codes.add(generateCode());
  }

  const rows = Array.from(codes).map((code) => ({
    code,
    created_by: admin.telegramId,
  }));

  const { data, error } = await supabase
    .from("loyalty_codes")
    .insert(rows)
    .select("id, code, created_at");

  if (error) {
    return NextResponse.json({ error: "db_error" }, { status: 500 });
  }

  return NextResponse.json({ codes: data });
}
