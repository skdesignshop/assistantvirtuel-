import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/require-admin";
import { supabaseServer } from "@/lib/supabase-server";
import type { AdminStats } from "@/types";

export const runtime = "nodejs";

export async function GET(req: NextRequest) {
  const admin = requireAdmin(req);
  if (!admin.ok) return admin.response;

  const supabase = supabaseServer();
  const now = new Date();
  const startOfToday = new Date(now);
  startOfToday.setHours(0, 0, 0, 0);
  const startOfWeek = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
  const startOfMonth = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

  const [
    { count: totalUsers },
    { count: newUsers7d },
    { count: activeToday },
    { count: activeWeek },
    { count: activeMonth },
    { count: totalMessages },
    { count: totalOrders },
    { count: loyaltyCompleted },
    { count: codesGenerated },
    { count: codesUsed },
    { count: usersStarted },
    { count: usersCompleted },
    { data: cityRows },
    { count: testimonialsTotal },
    { count: testimonialsVisible },
  ] = await Promise.all([
    supabase.from("users").select("*", { count: "exact", head: true }),
    supabase.from("users").select("*", { count: "exact", head: true }).gte("created_at", startOfWeek.toISOString()),
    supabase.from("users").select("*", { count: "exact", head: true }).gte("last_seen_at", startOfToday.toISOString()),
    supabase.from("users").select("*", { count: "exact", head: true }).gte("last_seen_at", startOfWeek.toISOString()),
    supabase.from("users").select("*", { count: "exact", head: true }).gte("last_seen_at", startOfMonth.toISOString()),
    supabase.from("messages").select("*", { count: "exact", head: true }),
    supabase.from("users").select("*", { count: "exact", head: true }).gt("order_count", 0),
    supabase.from("users").select("*", { count: "exact", head: true }).eq("loyalty_progress", 10),
    supabase.from("loyalty_codes").select("*", { count: "exact", head: true }),
    supabase.from("loyalty_codes").select("*", { count: "exact", head: true }).eq("used", true),
    supabase.from("users").select("*", { count: "exact", head: true }).gt("loyalty_progress", 0),
    supabase.from("users").select("*", { count: "exact", head: true }).eq("loyalty_progress", 10),
    supabase.from("users").select("city").not("city", "is", null),
    supabase.from("testimonials").select("*", { count: "exact", head: true }),
    supabase.from("testimonials").select("*", { count: "exact", head: true }).eq("visible", true),
  ]);

  const cityCounts = new Map<string, number>();
  for (const row of cityRows ?? []) {
    if (!row.city) continue;
    cityCounts.set(row.city, (cityCounts.get(row.city) ?? 0) + 1);
  }
  const usersPerCity = Array.from(cityCounts.entries())
    .map(([city, count]) => ({ city, count }))
    .sort((a, b) => b.count - a.count);

  const stats: AdminStats = {
    users: {
      total: totalUsers ?? 0,
      new_last_7_days: newUsers7d ?? 0,
      active_today: activeToday ?? 0,
      active_this_week: activeWeek ?? 0,
      active_this_month: activeMonth ?? 0,
    },
    activity: {
      total_visits: totalUsers ?? 0, // affiné si tu ajoutes un compteur de visites séparé
      total_conversations: 0, // calculé plus finement si besoin (group by telegram_user_id sur messages)
      total_messages: totalMessages ?? 0,
      total_orders: totalOrders ?? 0,
      loyalty_completed: loyaltyCompleted ?? 0,
      gifts_unlocked: loyaltyCompleted ?? 0,
    },
    loyalty: {
      codes_generated: codesGenerated ?? 0,
      codes_used: codesUsed ?? 0,
      codes_available: (codesGenerated ?? 0) - (codesUsed ?? 0),
      users_started: usersStarted ?? 0,
      users_completed: usersCompleted ?? 0,
    },
    cities: {
      users_per_city: usersPerCity,
      most_active_cities: usersPerCity.slice(0, 5),
    },
    testimonials: {
      total: testimonialsTotal ?? 0,
      visible: testimonialsVisible ?? 0,
      hidden: (testimonialsTotal ?? 0) - (testimonialsVisible ?? 0),
    },
  };

  return NextResponse.json({ stats });
}
