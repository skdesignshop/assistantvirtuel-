import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/require-admin";
import { supabaseServer } from "@/lib/supabase-server";

export const runtime = "nodejs";

export async function GET(req: NextRequest) {
  const admin = requireAdmin(req);
  if (!admin.ok) return admin.response;

  const supabase = supabaseServer();
  const search = req.nextUrl.searchParams.get("q")?.trim();
  const limit = Number(req.nextUrl.searchParams.get("limit") ?? 50);

  let query = supabase
    .from("users")
    .select(
      "id, telegram_id, first_name, last_name, username, photo_url, city, created_at, last_seen_at, order_count, loyalty_progress, is_admin"
    )
    .order("last_seen_at", { ascending: false })
    .limit(Math.min(limit, 200));

  if (search) {
    // Recherche sur prénom, username, ou telegram_id
    const asNumber = Number(search);
    if (!Number.isNaN(asNumber)) {
      query = query.eq("telegram_id", asNumber);
    } else {
      query = query.or(`first_name.ilike.%${search}%,username.ilike.%${search}%`);
    }
  }

  const { data, error } = await query;

  if (error) {
    return NextResponse.json({ error: "db_error" }, { status: 500 });
  }

  return NextResponse.json({ users: data });
}
