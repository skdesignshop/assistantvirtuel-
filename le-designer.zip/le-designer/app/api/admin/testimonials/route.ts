import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { requireAdmin } from "@/lib/require-admin";
import { supabaseServer } from "@/lib/supabase-server";

export const runtime = "nodejs";

const testimonialSchema = z.object({
  id: z.string().uuid().optional(),
  telegram_user_id: z.number().int().nullable().optional(),
  name: z.string().min(1).max(120),
  photo_url: z.string().url().nullable().optional(),
  city: z.string().max(120).nullable().optional(),
  message: z.string().min(1).max(2000),
  rating: z.number().int().min(1).max(5).nullable().optional(),
  visible: z.boolean().default(true),
});

export async function GET(req: NextRequest) {
  const admin = requireAdmin(req);
  if (!admin.ok) return admin.response;

  const supabase = supabaseServer();
  const { data, error } = await supabase
    .from("testimonials")
    .select("*")
    .order("created_at", { ascending: false });

  if (error) return NextResponse.json({ error: "db_error" }, { status: 500 });
  return NextResponse.json({ testimonials: data });
}

export async function POST(req: NextRequest) {
  const admin = requireAdmin(req);
  if (!admin.ok) return admin.response;

  const json = await req.json().catch(() => null);
  const parsed = testimonialSchema.omit({ id: true }).safeParse(json);
  if (!parsed.success) {
    return NextResponse.json({ error: "invalid_body", details: parsed.error.flatten() }, { status: 400 });
  }

  const supabase = supabaseServer();
  const { data, error } = await supabase.from("testimonials").insert(parsed.data).select("*").single();

  if (error) return NextResponse.json({ error: "db_error" }, { status: 500 });
  return NextResponse.json({ testimonial: data });
}

export async function PATCH(req: NextRequest) {
  const admin = requireAdmin(req);
  if (!admin.ok) return admin.response;

  const json = await req.json().catch(() => null);
  const parsed = testimonialSchema.partial().extend({ id: z.string().uuid() }).safeParse(json);
  if (!parsed.success) {
    return NextResponse.json({ error: "invalid_body", details: parsed.error.flatten() }, { status: 400 });
  }

  const { id, ...updates } = parsed.data;
  const supabase = supabaseServer();
  const { data, error } = await supabase.from("testimonials").update(updates).eq("id", id).select("*").single();

  if (error) return NextResponse.json({ error: "db_error" }, { status: 500 });
  return NextResponse.json({ testimonial: data });
}

export async function DELETE(req: NextRequest) {
  const admin = requireAdmin(req);
  if (!admin.ok) return admin.response;

  const id = req.nextUrl.searchParams.get("id");
  if (!id) return NextResponse.json({ error: "missing_id" }, { status: 400 });

  const supabase = supabaseServer();
  const { error } = await supabase.from("testimonials").delete().eq("id", id);

  if (error) return NextResponse.json({ error: "db_error" }, { status: 500 });
  return NextResponse.json({ success: true });
}
