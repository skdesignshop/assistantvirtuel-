import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { verifyRequestAuth } from "@/lib/telegram-auth";
import { supabaseServer } from "@/lib/supabase-server";

export const runtime = "nodejs";

const bodySchema = z.object({
  code: z
    .string()
    .trim()
    .min(3)
    .max(64)
    .transform((s) => s.toUpperCase()),
});

export async function POST(req: NextRequest) {
  const initDataHeader = req.headers.get("x-telegram-init-data");
  const verified = verifyRequestAuth(initDataHeader);

  if (!verified) {
    return NextResponse.json({ error: "invalid_telegram_signature" }, { status: 401 });
  }

  const json = await req.json().catch(() => null);
  const parsed = bodySchema.safeParse(json);
  if (!parsed.success) {
    return NextResponse.json({ error: "invalid_code_format" }, { status: 400 });
  }
  const { code } = parsed.data;

  const supabase = supabaseServer();

  const { data: profile, error: profileError } = await supabase
    .from("users")
    .select("id, loyalty_progress")
    .eq("telegram_id", verified.user.id)
    .maybeSingle();

  if (profileError || !profile) {
    return NextResponse.json({ error: "user_not_found" }, { status: 404 });
  }

  await supabase.from("app_events").insert({
    telegram_user_id: verified.user.id,
    event_type: "loyalty_code_attempt",
    metadata: { code },
  });

  // Appel de la fonction Postgres atomique (schema.sql) : verrouille la ligne
  // du code pour empêcher toute double-utilisation simultanée, met à jour
  // la progression de fidélité, et renvoie le résultat en une seule transaction.
  const { data: result, error: rpcError } = await supabase.rpc(
    "redeem_loyalty_code",
    { p_code: code, p_user_id: profile.id }
  );

  if (rpcError) {
    return NextResponse.json({ error: "db_error" }, { status: 500 });
  }

  if (!result?.success) {
    const reason = result?.error ?? "unknown_error";
    const status = reason === "code_not_found" ? 404 : 409;
    return NextResponse.json({ error: reason }, { status });
  }

  await supabase.from("app_events").insert({
    telegram_user_id: verified.user.id,
    event_type: "loyalty_code_success",
    metadata: { code },
  });

  if (result.gift_unlocked) {
    await supabase.from("app_events").insert({
      telegram_user_id: verified.user.id,
      event_type: "loyalty_completed",
      metadata: {},
    });
  }

  return NextResponse.json({
    success: true,
    loyalty_progress: result.loyalty_progress,
    order_count: result.order_count,
    gift_unlocked: result.gift_unlocked,
  });
}
