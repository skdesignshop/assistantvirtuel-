import { NextRequest, NextResponse } from "next/server";
import { verifyRequestAuth } from "@/lib/telegram-auth";
import { supabaseServer } from "@/lib/supabase-server";

export const runtime = "nodejs";

export async function GET(req: NextRequest) {
  const initDataHeader = req.headers.get("x-telegram-init-data");
  const verified = verifyRequestAuth(initDataHeader);
  if (!verified) {
    return NextResponse.json({ error: "invalid_telegram_signature" }, { status: 401 });
  }

  const supabase = supabaseServer();
  const { data, error } = await supabase
    .from("users")
    .select("loyalty_progress, order_count")
    .eq("telegram_id", verified.user.id)
    .maybeSingle();

  if (error || !data) {
    return NextResponse.json({ error: "user_not_found" }, { status: 404 });
  }

  return NextResponse.json({
    loyalty_progress: data.loyalty_progress,
    order_count: data.order_count,
    gift_unlocked: data.loyalty_progress >= 10,
  });
}
