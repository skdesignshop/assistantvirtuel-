import { NextRequest, NextResponse } from "next/server";
import { verifyRequestAuth, isAdminTelegramId } from "@/lib/telegram-auth";
import { supabaseServer } from "@/lib/supabase-server";

export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  const initDataHeader = req.headers.get("x-telegram-init-data");
  const verified = verifyRequestAuth(initDataHeader);

  if (!verified) {
    return NextResponse.json(
      { error: "invalid_telegram_signature" },
      { status: 401 }
    );
  }

  const { user } = verified;
  const supabase = supabaseServer();

  const { data: existing, error: fetchError } = await supabase
    .from("users")
    .select("*")
    .eq("telegram_id", user.id)
    .maybeSingle();

  if (fetchError) {
    return NextResponse.json({ error: "db_error" }, { status: 500 });
  }

  const admin = isAdminTelegramId(user.id);

  if (existing) {
    const { data: updated, error: updateError } = await supabase
      .from("users")
      .update({
        last_seen_at: new Date().toISOString(),
        visit_count: existing.visit_count + 1,
        first_name: user.first_name,
        last_name: user.last_name ?? existing.last_name,
        username: user.username ?? existing.username,
        photo_url: user.photo_url ?? existing.photo_url,
        is_admin: admin, // toujours recalculé côté serveur, jamais depuis le client
      })
      .eq("telegram_id", user.id)
      .select("*")
      .single();

    if (updateError) {
      return NextResponse.json({ error: "db_error" }, { status: 500 });
    }

    await logEvent(supabase, user.id, existing.visit_count === 1 ? "app_open" : "app_open");

    return NextResponse.json({ profile: updated, isNewUser: false });
  }

  const { data: created, error: insertError } = await supabase
    .from("users")
    .insert({
      telegram_id: user.id,
      first_name: user.first_name,
      last_name: user.last_name ?? null,
      username: user.username ?? null,
      photo_url: user.photo_url ?? null,
      is_admin: admin,
    })
    .select("*")
    .single();

  if (insertError) {
    return NextResponse.json({ error: "db_error" }, { status: 500 });
  }

  await logEvent(supabase, user.id, "first_visit");

  return NextResponse.json({ profile: created, isNewUser: true });
}

async function logEvent(
  supabase: ReturnType<typeof supabaseServer>,
  telegramId: number,
  eventType: string,
  metadata: Record<string, unknown> = {}
) {
  await supabase.from("app_events").insert({
    telegram_user_id: telegramId,
    event_type: eventType,
    metadata,
  });
}
