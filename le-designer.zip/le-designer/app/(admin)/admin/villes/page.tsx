"use client";

import { useEffect, useState } from "react";
import { apiFetch } from "@/lib/telegram-client";
import { AdminGuard } from "@/components/admin/AdminGuard";
import { AdminNav } from "@/components/admin/AdminNav";
import type { City } from "@/types";

const emptyForm = {
  name: "",
  country: "France",
  latitude: "",
  longitude: "",
  logo_url: "",
  description: "",
  visible: true,
};

function CitiesContent() {
  const [cities, setCities] = useState<City[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState<string | null>(null);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setLoading(true);
    try {
      const res = await apiFetch("/api/admin/cities");
      if (res.ok) {
        const data = await res.json();
        setCities(data.cities ?? []);
      }
    } finally {
      setLoading(false);
    }
  }

  function startEdit(city: City) {
    setEditingId(city.id);
    setForm({
      name: city.name,
      country: city.country,
      latitude: String(city.latitude),
      longitude: String(city.longitude),
      logo_url: city.logo_url ?? "",
      description: city.description ?? "",
      visible: city.visible,
    });
    setShowForm(true);
  }

  async function save() {
    const payload = {
      name: form.name,
      country: form.country,
      latitude: Number(form.latitude),
      longitude: Number(form.longitude),
      logo_url: form.logo_url || null,
      description: form.description || null,
      visible: form.visible,
    };

    if (editingId) {
      await apiFetch("/api/admin/cities", {
        method: "PATCH",
        body: JSON.stringify({ id: editingId, ...payload }),
      });
    } else {
      await apiFetch("/api/admin/cities", { method: "POST", body: JSON.stringify(payload) });
    }

    setForm(emptyForm);
    setEditingId(null);
    setShowForm(false);
    load();
  }

  async function toggleVisible(city: City) {
    await apiFetch("/api/admin/cities", {
      method: "PATCH",
      body: JSON.stringify({ id: city.id, visible: !city.visible }),
    });
    load();
  }

  async function remove(id: string) {
    await apiFetch(`/api/admin/cities?id=${id}`, { method: "DELETE" });
    load();
  }

  return (
    <div className="px-5 pb-10">
      <button
        onClick={() => {
          setForm(emptyForm);
          setEditingId(null);
          setShowForm(!showForm);
        }}
        className="w-full py-3 rounded-full bg-violet text-white text-sm font-semibold mb-4"
      >
        {showForm ? "Fermer" : "+ Ajouter une ville"}
      </button>

      {showForm && (
        <div className="glass-card rounded-xl2 p-4 mb-5 space-y-3">
          <input
            placeholder="Nom de la ville"
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            className="w-full bg-surfaceAlt rounded-lg px-3 py-2 text-sm outline-none"
          />
          <div className="flex gap-2">
            <input
              placeholder="Latitude"
              value={form.latitude}
              onChange={(e) => setForm({ ...form, latitude: e.target.value })}
              className="w-1/2 bg-surfaceAlt rounded-lg px-3 py-2 text-sm outline-none"
            />
            <input
              placeholder="Longitude"
              value={form.longitude}
              onChange={(e) => setForm({ ...form, longitude: e.target.value })}
              className="w-1/2 bg-surfaceAlt rounded-lg px-3 py-2 text-sm outline-none"
            />
          </div>
          <input
            placeholder="URL du logo (optionnel)"
            value={form.logo_url}
            onChange={(e) => setForm({ ...form, logo_url: e.target.value })}
            className="w-full bg-surfaceAlt rounded-lg px-3 py-2 text-sm outline-none"
          />
          <textarea
            placeholder="Description (optionnel)"
            value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
            className="w-full bg-surfaceAlt rounded-lg px-3 py-2 text-sm outline-none"
            rows={2}
          />
          <button
            onClick={save}
            disabled={!form.name || !form.latitude || !form.longitude}
            className="w-full py-2.5 rounded-full bg-accent text-background font-semibold disabled:opacity-40"
          >
            {editingId ? "Mettre à jour" : "Créer"}
          </button>
        </div>
      )}

      {loading ? (
        <p className="text-white/40 text-sm text-center py-6">Chargement…</p>
      ) : (
        <div className="space-y-2">
          {cities.map((c) => (
            <div key={c.id} className="glass-card rounded-xl p-3 flex items-center gap-3">
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold">{c.name}</p>
                <p className="text-xs text-white/40">
                  {c.latitude.toFixed(2)}, {c.longitude.toFixed(2)}
                </p>
              </div>
              <button
                onClick={() => toggleVisible(c)}
                className={`text-xs px-2 py-1 rounded-full ${
                  c.visible ? "bg-accent/20 text-accent" : "bg-white/5 text-white/40"
                }`}
              >
                {c.visible ? "visible" : "masquée"}
              </button>
              <button onClick={() => startEdit(c)} className="text-xs text-white/50 px-1">
                éditer
              </button>
              <button onClick={() => remove(c.id)} className="text-xs text-red-400 px-1">
                suppr.
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default function AdminCitiesPage() {
  return (
    <AdminGuard>
      <div className="min-h-screen pt-8">
        <header className="px-5 mb-2">
          <h1 className="text-2xl font-display font-bold">Espace admin</h1>
        </header>
        <AdminNav />
        <CitiesContent />
      </div>
    </AdminGuard>
  );
}
