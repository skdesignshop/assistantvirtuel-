"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { apiFetch } from "@/lib/telegram-client";
import { AdminGuard } from "@/components/admin/AdminGuard";
import { AdminNav } from "@/components/admin/AdminNav";
import type { AppUser } from "@/types";

function UsersContent() {
  const [users, setUsers] = useState<AppUser[]>([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    load(search);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function load(q: string) {
    setLoading(true);
    try {
      const res = await apiFetch(`/api/admin/users?q=${encodeURIComponent(q)}`);
      if (res.ok) {
        const data = await res.json();
        setUsers(data.users ?? []);
      }
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="px-5 pb-10">
      <input
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        onKeyDown={(e) => e.key === "Enter" && load(search)}
        placeholder="Rechercher par prénom, username, ID Telegram…"
        className="w-full bg-surfaceAlt rounded-full px-4 py-2.5 text-sm outline-none placeholder:text-white/30 mb-4"
      />

      {loading ? (
        <p className="text-white/40 text-sm text-center py-6">Chargement…</p>
      ) : users.length === 0 ? (
        <p className="text-white/40 text-sm text-center py-6">Aucun utilisateur trouvé.</p>
      ) : (
        <div className="space-y-2">
          {users.map((u) => (
            <div key={u.id} className="glass-card rounded-xl p-3 flex items-center gap-3">
              {u.photo_url ? (
                <Image src={u.photo_url} alt={u.first_name} width={40} height={40} className="rounded-full" />
              ) : (
                <div className="w-10 h-10 rounded-full bg-accent/20" />
              )}
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold truncate">
                  {u.first_name} {u.last_name ?? ""}
                  {u.is_admin && <span className="ml-2 text-[10px] text-violet">ADMIN</span>}
                </p>
                <p className="text-xs text-white/40 truncate">
                  {u.username ? `@${u.username} · ` : ""}ID {u.telegram_id}
                  {u.city ? ` · ${u.city}` : ""}
                </p>
              </div>
              <div className="text-right text-xs text-white/50 flex-shrink-0">
                <p>{u.order_count} commandes</p>
                <p>{u.loyalty_progress}/10 fidélité</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default function AdminUsersPage() {
  return (
    <AdminGuard>
      <div className="min-h-screen pt-8">
        <header className="px-5 mb-2">
          <h1 className="text-2xl font-display font-bold">Espace admin</h1>
        </header>
        <AdminNav />
        <UsersContent />
      </div>
    </AdminGuard>
  );
}
