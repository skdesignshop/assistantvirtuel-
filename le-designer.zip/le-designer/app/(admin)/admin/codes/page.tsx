"use client";

import { useEffect, useState } from "react";
import { apiFetch } from "@/lib/telegram-client";
import { AdminGuard } from "@/components/admin/AdminGuard";
import { AdminNav } from "@/components/admin/AdminNav";
import type { LoyaltyCode } from "@/types";

const COUNT_OPTIONS = [1, 10, 50, 100];

function CodesContent() {
  const [codes, setCodes] = useState<LoyaltyCode[]>([]);
  const [filter, setFilter] = useState<"all" | "used" | "available">("all");
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [justGenerated, setJustGenerated] = useState<string[]>([]);

  useEffect(() => {
    load(filter);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filter]);

  async function load(f: typeof filter) {
    setLoading(true);
    try {
      const statusParam = f === "all" ? "" : `?status=${f}`;
      const res = await apiFetch(`/api/admin/codes${statusParam}`);
      if (res.ok) {
        const data = await res.json();
        setCodes(data.codes ?? []);
      }
    } finally {
      setLoading(false);
    }
  }

  async function generate(count: number) {
    setGenerating(true);
    setJustGenerated([]);
    try {
      const res = await apiFetch("/api/admin/generate-codes", {
        method: "POST",
        body: JSON.stringify({ count }),
      });
      if (res.ok) {
        const data = await res.json();
        setJustGenerated(data.codes.map((c: { code: string }) => c.code));
        load(filter);
      }
    } finally {
      setGenerating(false);
    }
  }

  function copyAll() {
    navigator.clipboard.writeText(justGenerated.join("\n"));
  }

  return (
    <div className="px-5 pb-10">
      <div className="glass-card rounded-xl2 p-4 mb-5">
        <p className="text-sm font-semibold mb-3">Générer des codes</p>
        <div className="flex gap-2 flex-wrap">
          {COUNT_OPTIONS.map((n) => (
            <button
              key={n}
              onClick={() => generate(n)}
              disabled={generating}
              className="px-4 py-2 rounded-full bg-violet text-white text-sm disabled:opacity-40"
            >
              +{n}
            </button>
          ))}
        </div>

        {justGenerated.length > 0 && (
          <div className="mt-4">
            <div className="flex items-center justify-between mb-2">
              <p className="text-xs text-white/50">{justGenerated.length} codes générés</p>
              <button onClick={copyAll} className="text-xs text-accent">
                Copier tout
              </button>
            </div>
            <div className="bg-surfaceAlt rounded-lg p-3 max-h-40 overflow-y-auto font-mono text-xs space-y-1">
              {justGenerated.map((c) => (
                <p key={c}>{c}</p>
              ))}
            </div>
          </div>
        )}
      </div>

      <div className="flex gap-2 mb-4">
        {(["all", "available", "used"] as const).map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-3 py-1.5 rounded-full text-xs ${
              filter === f ? "bg-accent text-background" : "glass-card text-white/50"
            }`}
          >
            {f === "all" ? "Tous" : f === "available" ? "Disponibles" : "Utilisés"}
          </button>
        ))}
      </div>

      {loading ? (
        <p className="text-white/40 text-sm text-center py-6">Chargement…</p>
      ) : (
        <div className="space-y-2">
          {codes.map((c) => (
            <div key={c.id} className="glass-card rounded-lg px-4 py-2.5 flex items-center justify-between">
              <span className="font-mono text-sm">{c.code}</span>
              <span className={`text-xs ${c.used ? "text-white/30" : "text-accent"}`}>
                {c.used ? "utilisé" : "disponible"}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default function AdminCodesPage() {
  return (
    <AdminGuard>
      <div className="min-h-screen pt-8">
        <header className="px-5 mb-2">
          <h1 className="text-2xl font-display font-bold">Espace admin</h1>
        </header>
        <AdminNav />
        <CodesContent />
      </div>
    </AdminGuard>
  );
}
