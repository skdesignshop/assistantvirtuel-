"use client";

import { useEffect, useState } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { apiFetch } from "@/lib/telegram-client";
import { AdminGuard } from "@/components/admin/AdminGuard";
import { AdminNav } from "@/components/admin/AdminNav";
import type { AdminStats } from "@/types";

function StatCard({ label, value }: { label: string; value: number | string }) {
  return (
    <div className="glass-card rounded-xl p-4">
      <p className="text-2xl font-display font-bold">{value}</p>
      <p className="text-xs text-white/50 mt-1">{label}</p>
    </div>
  );
}

function DashboardContent() {
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setLoading(true);
    try {
      const res = await apiFetch("/api/admin/stats");
      if (res.ok) {
        const data = await res.json();
        setStats(data.stats);
      }
    } finally {
      setLoading(false);
    }
  }

  if (loading || !stats) {
    return <div className="text-center text-white/40 text-sm py-10">Chargement des statistiques…</div>;
  }

  return (
    <div className="px-5 pb-10 space-y-8">
      <section>
        <h2 className="font-display font-semibold mb-3">Utilisateurs</h2>
        <div className="grid grid-cols-2 gap-3">
          <StatCard label="Total utilisateurs" value={stats.users.total} />
          <StatCard label="Nouveaux (7j)" value={stats.users.new_last_7_days} />
          <StatCard label="Actifs aujourd'hui" value={stats.users.active_today} />
          <StatCard label="Actifs ce mois" value={stats.users.active_this_month} />
        </div>
      </section>

      <section>
        <h2 className="font-display font-semibold mb-3">Activité</h2>
        <div className="grid grid-cols-2 gap-3">
          <StatCard label="Messages envoyés" value={stats.activity.total_messages} />
          <StatCard label="Commandes" value={stats.activity.total_orders} />
          <StatCard label="Cartes complétées" value={stats.activity.loyalty_completed} />
          <StatCard label="Cadeaux débloqués" value={stats.activity.gifts_unlocked} />
        </div>
      </section>

      <section>
        <h2 className="font-display font-semibold mb-3">Fidélité</h2>
        <div className="grid grid-cols-2 gap-3">
          <StatCard label="Codes générés" value={stats.loyalty.codes_generated} />
          <StatCard label="Codes utilisés" value={stats.loyalty.codes_used} />
          <StatCard label="Codes disponibles" value={stats.loyalty.codes_available} />
          <StatCard label="Cartes commencées" value={stats.loyalty.users_started} />
        </div>
      </section>

      <section>
        <h2 className="font-display font-semibold mb-3">Utilisateurs par ville</h2>
        {stats.cities.users_per_city.length === 0 ? (
          <p className="text-white/40 text-sm">Aucune donnée de ville pour le moment.</p>
        ) : (
          <div className="glass-card rounded-xl p-4 h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.cities.users_per_city}>
                <XAxis dataKey="city" stroke="#ffffff40" fontSize={11} />
                <YAxis stroke="#ffffff40" fontSize={11} allowDecimals={false} />
                <Tooltip
                  contentStyle={{ background: "#1C1C28", border: "none", borderRadius: 8 }}
                />
                <Bar dataKey="count" fill="#3ADE7C" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}
      </section>

      <section>
        <h2 className="font-display font-semibold mb-3">Avis</h2>
        <div className="grid grid-cols-3 gap-3">
          <StatCard label="Total" value={stats.testimonials.total} />
          <StatCard label="Visibles" value={stats.testimonials.visible} />
          <StatCard label="Masqués" value={stats.testimonials.hidden} />
        </div>
      </section>
    </div>
  );
}

export default function AdminDashboardPage() {
  return (
    <AdminGuard>
      <div className="min-h-screen pt-8">
        <header className="px-5 mb-2">
          <h1 className="text-2xl font-display font-bold">Espace admin</h1>
        </header>
        <AdminNav />
        <DashboardContent />
      </div>
    </AdminGuard>
  );
}
