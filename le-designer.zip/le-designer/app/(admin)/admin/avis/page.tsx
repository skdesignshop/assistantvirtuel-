"use client";

import { useEffect, useState } from "react";
import { apiFetch } from "@/lib/telegram-client";
import { AdminGuard } from "@/components/admin/AdminGuard";
import { AdminNav } from "@/components/admin/AdminNav";
import type { Testimonial } from "@/types";

const emptyForm = { name: "", city: "", message: "", photo_url: "", rating: "5" };

function TestimonialsContent() {
  const [items, setItems] = useState<Testimonial[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(emptyForm);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setLoading(true);
    try {
      const res = await apiFetch("/api/admin/testimonials");
      if (res.ok) {
        const data = await res.json();
        setItems(data.testimonials ?? []);
      }
    } finally {
      setLoading(false);
    }
  }

  async function create() {
    await apiFetch("/api/admin/testimonials", {
      method: "POST",
      body: JSON.stringify({
        name: form.name,
        city: form.city || null,
        message: form.message,
        photo_url: form.photo_url || null,
        rating: Number(form.rating),
        visible: true,
      }),
    });
    setForm(emptyForm);
    setShowForm(false);
    load();
  }

  async function toggleVisible(t: Testimonial) {
    await apiFetch("/api/admin/testimonials", {
      method: "PATCH",
      body: JSON.stringify({ id: t.id, visible: !t.visible }),
    });
    load();
  }

  async function remove(id: string) {
    await apiFetch(`/api/admin/testimonials?id=${id}`, { method: "DELETE" });
    load();
  }

  return (
    <div className="px-5 pb-10">
      <button
        onClick={() => setShowForm(!showForm)}
        className="w-full py-3 rounded-full bg-violet text-white text-sm font-semibold mb-4"
      >
        {showForm ? "Fermer" : "+ Ajouter un avis"}
      </button>

      {showForm && (
        <div className="glass-card rounded-xl2 p-4 mb-5 space-y-3">
          <input
            placeholder="Prénom"
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            className="w-full bg-surfaceAlt rounded-lg px-3 py-2 text-sm outline-none"
          />
          <input
            placeholder="Ville (optionnel)"
            value={form.city}
            onChange={(e) => setForm({ ...form, city: e.target.value })}
            className="w-full bg-surfaceAlt rounded-lg px-3 py-2 text-sm outline-none"
          />
          <textarea
            placeholder="Message"
            value={form.message}
            onChange={(e) => setForm({ ...form, message: e.target.value })}
            className="w-full bg-surfaceAlt rounded-lg px-3 py-2 text-sm outline-none"
            rows={3}
          />
          <input
            placeholder="URL photo (optionnel)"
            value={form.photo_url}
            onChange={(e) => setForm({ ...form, photo_url: e.target.value })}
            className="w-full bg-surfaceAlt rounded-lg px-3 py-2 text-sm outline-none"
          />
          <select
            value={form.rating}
            onChange={(e) => setForm({ ...form, rating: e.target.value })}
            className="w-full bg-surfaceAlt rounded-lg px-3 py-2 text-sm outline-none"
          >
            {[5, 4, 3, 2, 1].map((n) => (
              <option key={n} value={n}>
                {n} étoiles
              </option>
            ))}
          </select>
          <button
            onClick={create}
            disabled={!form.name || !form.message}
            className="w-full py-2.5 rounded-full bg-accent text-background font-semibold disabled:opacity-40"
          >
            Créer
          </button>
        </div>
      )}

      {loading ? (
        <p className="text-white/40 text-sm text-center py-6">Chargement…</p>
      ) : (
        <div className="space-y-2">
          {items.map((t) => (
            <div key={t.id} className="glass-card rounded-xl p-3">
              <div className="flex items-center justify-between mb-1">
                <p className="text-sm font-semibold">
                  {t.name} {t.city && <span className="text-white/40">· {t.city}</span>}
                </p>
                <div className="flex gap-2">
                  <button
                    onClick={() => toggleVisible(t)}
                    className={`text-xs px-2 py-1 rounded-full ${
                      t.visible ? "bg-accent/20 text-accent" : "bg-white/5 text-white/40"
                    }`}
                  >
                    {t.visible ? "visible" : "masqué"}
                  </button>
                  <button onClick={() => remove(t.id)} className="text-xs text-red-400">
                    suppr.
                  </button>
                </div>
              </div>
              <p className="text-xs text-white/60">{t.message}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default function AdminTestimonialsPage() {
  return (
    <AdminGuard>
      <div className="min-h-screen pt-8">
        <header className="px-5 mb-2">
          <h1 className="text-2xl font-display font-bold">Espace admin</h1>
        </header>
        <AdminNav />
        <TestimonialsContent />
      </div>
    </AdminGuard>
  );
}
