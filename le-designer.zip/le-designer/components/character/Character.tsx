"use client";

import { Suspense } from "react";
import { Canvas } from "@react-three/fiber";
import { Environment, OrbitControls, useGLTF } from "@react-three/drei";
import { motion } from "framer-motion";

/**
 * PERSONNAGE — LE DESIGNER
 * ------------------------------------------------------------------
 * Le modèle 3D définitif (masque noir, maillot vert, chaussures à
 * détails violets, ordinateur sous le bras) n'est pas encore fourni.
 *
 * Pour brancher ton propre modèle :
 * 1. Exporte ton personnage au format .glb
 * 2. Place-le dans /public/assets/character/character.glb
 * 3. Décommente le bloc <Model /> ci-dessous et supprime <PlaceholderAvatar />
 *
 * En attendant, un avatar 2D animé (silhouette + couleurs du personnage)
 * sert de placeholder pour que toute l'interface (accueil, assistant,
 * validation fidélité) soit déjà fonctionnelle.
 * ------------------------------------------------------------------
 */

function Model() {
  const { scene } = useGLTF("/assets/character/character.glb");
  return <primitive object={scene} scale={1.4} position={[0, -1.2, 0]} />;
}
useGLTF.preload("/assets/character/character.glb");

function PlaceholderAvatar({ animated = true }: { animated?: boolean }) {
  return (
    <motion.div
      className="relative w-40 h-40 md:w-56 md:h-56 mx-auto"
      animate={animated ? { y: [0, -10, 0] } : undefined}
      transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
    >
      <div className="absolute inset-0 rounded-full bg-accent/20 blur-2xl" />
      <svg viewBox="0 0 200 200" className="relative w-full h-full drop-shadow-2xl">
        {/* Corps / maillot vert */}
        <path
          d="M60 90 Q100 70 140 90 L150 190 L50 190 Z"
          fill="#3ADE7C"
          stroke="#1FA85A"
          strokeWidth="3"
        />
        {/* Numéro 3D style */}
        <text x="100" y="150" textAnchor="middle" fontSize="36" fill="#0A0A0F" fontWeight="bold">
          7
        </text>
        {/* Tête / masque noir */}
        <circle cx="100" cy="55" r="42" fill="#111318" stroke="#000" strokeWidth="2" />
        {/* Fentes des yeux du masque */}
        <ellipse cx="82" cy="52" rx="10" ry="5" fill="#3ADE7C" />
        <ellipse cx="118" cy="52" rx="10" ry="5" fill="#3ADE7C" />
        {/* Détails violets (chaussures stylisées en bas) */}
        <rect x="60" y="185" width="25" height="10" rx="4" fill="#8B5CF6" />
        <rect x="115" y="185" width="25" height="10" rx="4" fill="#8B5CF6" />
      </svg>
    </motion.div>
  );
}

export function Character3D({
  interactive = false,
  animated = true,
}: {
  interactive?: boolean;
  animated?: boolean;
}) {
  const hasRealModel = false; // passe à true une fois character.glb ajouté

  if (!hasRealModel) {
    return <PlaceholderAvatar animated={animated} />;
  }

  return (
    <div className="w-full h-64 md:h-80">
      <Canvas camera={{ position: [0, 0.5, 4], fov: 40 }}>
        <ambientLight intensity={0.8} />
        <directionalLight position={[3, 5, 2]} intensity={1.2} />
        <Suspense fallback={null}>
          <Model />
          <Environment preset="city" />
        </Suspense>
        {interactive && <OrbitControls enableZoom={false} enablePan={false} />}
      </Canvas>
    </div>
  );
}
