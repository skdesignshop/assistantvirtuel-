"use client";

import { Suspense, useRef, useState } from "react";
import { Canvas, useFrame, ThreeEvent } from "@react-three/fiber";
import { OrbitControls } from "@react-three/drei";
import * as THREE from "three";
import type { City } from "@/types";

function latLngToVector3(lat: number, lng: number, radius: number) {
  const phi = (90 - lat) * (Math.PI / 180);
  const theta = (lng + 180) * (Math.PI / 180);
  const x = -radius * Math.sin(phi) * Math.cos(theta);
  const y = radius * Math.cos(phi);
  const z = radius * Math.sin(phi) * Math.sin(theta);
  return new THREE.Vector3(x, y, z);
}

function RotatingEarth({ children }: { children: React.ReactNode }) {
  const groupRef = useRef<THREE.Group>(null);
  useFrame((_, delta) => {
    if (groupRef.current) groupRef.current.rotation.y += delta * 0.06;
  });
  return (
    <group ref={groupRef}>
      <mesh>
        <sphereGeometry args={[2, 64, 64]} />
        <meshStandardMaterial color="#14141C" roughness={0.7} metalness={0.2} />
      </mesh>
      {/* Lignes de longitude/latitude simplifiées pour donner du relief */}
      <mesh>
        <sphereGeometry args={[2.001, 24, 16]} />
        <meshBasicMaterial color="#3ADE7C" wireframe transparent opacity={0.08} />
      </mesh>
      {children}
    </group>
  );
}

function CityMarker({
  city,
  onSelect,
}: {
  city: City;
  onSelect: (c: City) => void;
}) {
  const position = latLngToVector3(city.latitude, city.longitude, 2.03);
  const [hovered, setHovered] = useState(false);

  function handleClick(e: ThreeEvent<MouseEvent>) {
    e.stopPropagation();
    onSelect(city);
  }

  return (
    <mesh
      position={position}
      onClick={handleClick}
      onPointerOver={() => setHovered(true)}
      onPointerOut={() => setHovered(false)}
    >
      <sphereGeometry args={[hovered ? 0.045 : 0.032, 16, 16]} />
      <meshStandardMaterial
        color={hovered ? "#E8C468" : "#3ADE7C"}
        emissive={hovered ? "#E8C468" : "#3ADE7C"}
        emissiveIntensity={0.8}
      />
    </mesh>
  );
}

export function Globe3D({
  cities,
  onSelectCity,
}: {
  cities: City[];
  onSelectCity: (c: City) => void;
}) {
  return (
    <div className="w-full h-72 md:h-96">
      <Canvas camera={{ position: [0, 0, 5.5], fov: 45 }}>
        <ambientLight intensity={0.9} />
        <directionalLight position={[5, 3, 5]} intensity={1} />
        <Suspense fallback={null}>
          <RotatingEarth>
            {cities.map((city) => (
              <CityMarker key={city.id} city={city} onSelect={onSelectCity} />
            ))}
          </RotatingEarth>
        </Suspense>
        <OrbitControls
          enablePan={false}
          minDistance={3.5}
          maxDistance={8}
          autoRotate={false}
        />
      </Canvas>
    </div>
  );
}
