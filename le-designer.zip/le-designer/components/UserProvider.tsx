"use client";

import { createContext, useContext, useEffect, useState } from "react";
import { getTelegramWebApp, apiFetch } from "@/lib/telegram-client";
import type { AppUser } from "@/types";

interface UserContextValue {
  user: AppUser | null;
  loading: boolean;
  error: string | null;
  isNewUser: boolean;
  refresh: () => Promise<void>;
}

const UserContext = createContext<UserContextValue>({
  user: null,
  loading: true,
  error: null,
  isNewUser: false,
  refresh: async () => {},
});

export function useAppUser() {
  return useContext(UserContext);
}

export function UserProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AppUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isNewUser, setIsNewUser] = useState(false);

  async function authenticate() {
    setLoading(true);
    setError(null);
    try {
      const tg = getTelegramWebApp();
      tg?.ready();
      tg?.expand();

      const res = await apiFetch("/api/auth/telegram", { method: "POST" });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error ?? "auth_failed");
      }
      const data = await res.json();
      setUser(data.profile);
      setIsNewUser(data.isNewUser);
    } catch (err) {
      setError(err instanceof Error ? err.message : "unknown_error");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    authenticate();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <UserContext.Provider value={{ user, loading, error, isNewUser, refresh: authenticate }}>
      {children}
    </UserContext.Provider>
  );
}
