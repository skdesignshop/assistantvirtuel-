"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useAppUser } from "@/components/UserProvider";

const ITEMS = [
  { href: "/accueil", label: "Accueil", icon: "🏠" },
  { href: "/assistant", label: "Assistant", icon: "💬" },
  { href: "/villes", label: "Villes", icon: "🌍" },
  { href: "/fidelite", label: "Fidélité", icon: "🎁" },
];

export function BottomNav() {
  const pathname = usePathname();
  const { user } = useAppUser();

  return (
    <nav className="fixed bottom-0 inset-x-0 z-50 glass-card border-t border-white/5 px-2 pb-[env(safe-area-inset-bottom)]">
      <div className="flex items-center justify-around max-w-md mx-auto">
        {ITEMS.map((item) => {
          const active = pathname?.startsWith(item.href);
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex flex-col items-center gap-0.5 py-2.5 px-3 flex-1 transition-colors ${
                active ? "text-accent" : "text-white/40"
              }`}
            >
              <span className="text-lg">{item.icon}</span>
              <span className="text-[11px] font-medium">{item.label}</span>
            </Link>
          );
        })}
        {user?.is_admin && (
          <Link
            href="/admin/dashboard"
            className={`flex flex-col items-center gap-0.5 py-2.5 px-3 flex-1 ${
              pathname?.startsWith("/admin") ? "text-violet" : "text-white/40"
            }`}
          >
            <span className="text-lg">⚙️</span>
            <span className="text-[11px] font-medium">Admin</span>
          </Link>
        )}
      </div>
    </nav>
  );
}
