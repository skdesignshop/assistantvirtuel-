"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const ITEMS = [
  { href: "/admin/dashboard", label: "Statistiques" },
  { href: "/admin/utilisateurs", label: "Utilisateurs" },
  { href: "/admin/codes", label: "Codes" },
  { href: "/admin/villes", label: "Villes" },
  { href: "/admin/avis", label: "Avis" },
];

export function AdminNav() {
  const pathname = usePathname();
  return (
    <div className="flex gap-2 overflow-x-auto px-5 pb-3 pt-1 -mx-1">
      {ITEMS.map((item) => {
        const active = pathname === item.href;
        return (
          <Link
            key={item.href}
            href={item.href}
            className={`px-4 py-2 rounded-full text-sm whitespace-nowrap flex-shrink-0 ${
              active ? "bg-violet text-white" : "glass-card text-white/60"
            }`}
          >
            {item.label}
          </Link>
        );
      })}
    </div>
  );
}
