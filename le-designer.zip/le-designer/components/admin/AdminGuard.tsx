"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAppUser } from "@/components/UserProvider";
import { useTelegramBackButton } from "@/lib/use-telegram-back-button";

/**
 * Garde-fou côté CLIENT (UX uniquement) : redirige un non-admin.
 * ⚠️ Ce n'est qu'un confort d'affichage — la vraie protection est côté
 * serveur, dans lib/require-admin.ts, appelé par chaque route /api/admin/**.
 * Même si quelqu'un contourne cet écran, aucune donnée sensible n'est
 * accessible sans passer la vérification serveur.
 */
export function AdminGuard({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAppUser();
  const router = useRouter();

  useTelegramBackButton(() => router.push("/accueil"), !loading && !!user?.is_admin);

  useEffect(() => {
    if (!loading && (!user || !user.is_admin)) {
      router.replace("/accueil");
    }
  }, [loading, user, router]);

  if (loading || !user?.is_admin) {
    return (
      <div className="min-h-screen flex items-center justify-center text-white/40 text-sm">
        Vérification des droits…
      </div>
    );
  }

  return <>{children}</>;
}
