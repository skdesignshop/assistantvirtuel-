"use client";

import { motion } from "framer-motion";

export function LoyaltyCard({ progress }: { progress: number }) {
  const slots = Array.from({ length: 10 }, (_, i) => i + 1);

  return (
    <div className="glass-card rounded-xl2 p-6 shadow-card">
      <div className="text-center mb-6">
        <p className="text-xs tracking-widest text-accent uppercase">LE DESIGNER</p>
        <h2 className="text-xl font-display font-bold mt-1">CARTE DE FIDÉLITÉ</h2>
      </div>

      <div className="grid grid-cols-5 gap-3">
        {slots.map((slot) => {
          const filled = slot <= progress;
          return (
            <motion.div
              key={slot}
              initial={false}
              animate={filled ? { scale: [1, 1.2, 1] } : {}}
              transition={{ duration: 0.4 }}
              className={`aspect-square rounded-full flex items-center justify-center text-sm font-semibold border-2 ${
                filled
                  ? "bg-accent border-accent text-background"
                  : "border-white/15 text-white/30"
              }`}
            >
              {filled ? "✓" : slot}
            </motion.div>
          );
        })}
      </div>

      {progress >= 10 && (
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="mt-6 text-center py-3 rounded-xl bg-gold/15 border border-gold/40"
        >
          <p className="text-gold font-display font-bold">🎁 CADEAU OFFERT</p>
        </motion.div>
      )}
    </div>
  );
}
