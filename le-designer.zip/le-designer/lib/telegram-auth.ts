import crypto from "crypto";

export interface TelegramWebAppUser {
  id: number;
  first_name: string;
  last_name?: string;
  username?: string;
  photo_url?: string;
  language_code?: string;
}

export interface VerifiedTelegramData {
  user: TelegramWebAppUser;
  authDate: number;
}

/**
 * Vérifie la signature HMAC-SHA256 de l'initData envoyée par Telegram WebApp.
 * C'est LA seule façon fiable de savoir qu'un utilisateur est bien qui il
 * prétend être : on ne fait jamais confiance à un telegram_id envoyé "en clair"
 * par le frontend sans repasser par cette vérification.
 *
 * Doc Telegram: https://core.telegram.org/bots/webapps#validating-data-received-via-the-mini-app
 */
export function verifyTelegramInitData(
  initData: string,
  botToken: string,
  maxAgeSeconds = 86400
): VerifiedTelegramData | null {
  if (!initData || !botToken) return null;

  const params = new URLSearchParams(initData);
  const hash = params.get("hash");
  if (!hash) return null;

  params.delete("hash");

  // Construit la chaîne de vérification triée par clé, format "key=value" joint par \n
  const dataCheckArr: string[] = [];
  params.forEach((value, key) => {
    dataCheckArr.push(`${key}=${value}`);
  });
  dataCheckArr.sort();
  const dataCheckString = dataCheckArr.join("\n");

  // secret_key = HMAC_SHA256("WebAppData", bot_token)
  const secretKey = crypto
    .createHmac("sha256", "WebAppData")
    .update(botToken)
    .digest();

  const computedHash = crypto
    .createHmac("sha256", secretKey)
    .update(dataCheckString)
    .digest("hex");

  // Comparaison en temps constant pour éviter les timing attacks
  const hashBuffer = Buffer.from(hash, "hex");
  const computedBuffer = Buffer.from(computedHash, "hex");
  if (
    hashBuffer.length !== computedBuffer.length ||
    !crypto.timingSafeEqual(hashBuffer, computedBuffer)
  ) {
    return null;
  }

  const authDate = Number(params.get("auth_date"));
  if (!authDate || Date.now() / 1000 - authDate > maxAgeSeconds) {
    return null; // initData trop ancienne -> refusée
  }

  const userRaw = params.get("user");
  if (!userRaw) return null;

  let user: TelegramWebAppUser;
  try {
    user = JSON.parse(userRaw);
  } catch {
    return null;
  }

  if (!user?.id) return null;

  return { user, authDate };
}

/**
 * Vérifie si un telegram_id fait partie des admins configurés
 * (variable d'environnement ADMIN_TELEGRAM_IDS="123,456").
 */
export function isAdminTelegramId(telegramId: number): boolean {
  const raw = process.env.ADMIN_TELEGRAM_IDS ?? "";
  const ids = raw
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean)
    .map(Number);
  return ids.includes(telegramId);
}

/**
 * Extrait et vérifie l'initData depuis les headers d'une requête API,
 * à utiliser dans CHAQUE route sensible (jamais faire confiance à un body
 * qui contiendrait juste telegram_id).
 */
export function verifyRequestAuth(initDataHeader: string | null) {
  const botToken = process.env.TELEGRAM_BOT_TOKEN;
  if (!botToken) {
    throw new Error("TELEGRAM_BOT_TOKEN manquant dans les variables d'environnement");
  }
  if (!initDataHeader) return null;
  return verifyTelegramInitData(initDataHeader, botToken);
}
