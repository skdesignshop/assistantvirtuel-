import { NextRequest, NextResponse } from "next/server";
import { verifyRequestAuth, isAdminTelegramId } from "@/lib/telegram-auth";

/**
 * À appeler en première ligne de CHAQUE route /api/admin/**.
 * Revalide l'identité Telegram ET vérifie que le telegram_id fait partie
 * de ADMIN_TELEGRAM_IDS -> un utilisateur normal ne peut jamais devenir
 * admin depuis le frontend, seule la variable d'environnement fait foi.
 */
export function requireAdmin(req: NextRequest) {
  const initDataHeader = req.headers.get("x-telegram-init-data");
  const verified = verifyRequestAuth(initDataHeader);

  if (!verified) {
    return {
      ok: false as const,
      response: NextResponse.json({ error: "invalid_telegram_signature" }, { status: 401 }),
    };
  }

  if (!isAdminTelegramId(verified.user.id)) {
    return {
      ok: false as const,
      response: NextResponse.json({ error: "forbidden" }, { status: 403 }),
    };
  }

  return { ok: true as const, telegramId: verified.user.id };
}
