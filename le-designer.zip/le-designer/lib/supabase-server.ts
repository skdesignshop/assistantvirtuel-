import { createClient } from "@supabase/supabase-js";

/**
 * Client Supabase côté SERVEUR uniquement (routes API / server components).
 * Utilise la clé service_role qui bypass RLS -> ne JAMAIS importer ce fichier
 * dans un composant client ("use client") ni l'exposer au frontend.
 */
function getServerSupabase() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!url || !serviceKey) {
    throw new Error(
      "Supabase non configuré: renseigne NEXT_PUBLIC_SUPABASE_URL et SUPABASE_SERVICE_ROLE_KEY dans .env.local"
    );
  }

  return createClient(url, serviceKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}

export const supabaseServer = getServerSupabase;
