/**
 * Couche d'abstraction du fournisseur IA.
 * L'AI_API_KEY n'est JAMAIS envoyée au frontend : tout passe par cette
 * fonction, appelée uniquement depuis /app/api/assistant/chat/route.ts.
 *
 * Pour changer de fournisseur : ajouter un cas dans le switch ci-dessous.
 * Le reste de l'application (page assistant, historique en base) n'a pas
 * besoin de changer.
 */

export interface ChatMessage {
  role: "user" | "assistant" | "system";
  content: string;
}

export async function getAssistantReply(
  history: ChatMessage[],
  systemPrompt: string
): Promise<string> {
  const provider = process.env.AI_PROVIDER ?? "anthropic";
  const apiKey = process.env.AI_API_KEY;
  const model = process.env.AI_MODEL ?? "claude-sonnet-4-6";

  if (!apiKey) {
    throw new Error(
      "AI_API_KEY manquante. Renseigne-la dans .env.local une fois ton fournisseur IA choisi."
    );
  }

  switch (provider) {
    case "anthropic":
      return callAnthropic(history, systemPrompt, apiKey, model);
    // case "openai":
    //   return callOpenAI(history, systemPrompt, apiKey, model);
    default:
      throw new Error(`Fournisseur IA inconnu: ${provider}`);
  }
}

async function callAnthropic(
  history: ChatMessage[],
  systemPrompt: string,
  apiKey: string,
  model: string
): Promise<string> {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model,
      max_tokens: 1024,
      system: systemPrompt,
      messages: history
        .filter((m) => m.role !== "system")
        .map((m) => ({ role: m.role, content: m.content })),
    }),
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Erreur API IA (${res.status}): ${errText}`);
  }

  const data = await res.json();
  const textBlock = data.content?.find((b: { type: string }) => b.type === "text");
  return textBlock?.text ?? "Désolé, je n'ai pas pu générer de réponse.";
}

/**
 * Le system prompt / knowledge base de l'assistant.
 * ⚠️ À REMPLIR : services, tarifs, règles, FAQ de LE DESIGNER.
 * Le stocker ici (ou dans Supabase, table "assistant_config", pour le
 * modifier depuis l'admin sans redéployer) permet de le changer sans
 * toucher au reste de l'application.
 */
export function getSystemPrompt(): string {
  return (
    process.env.ASSISTANT_SYSTEM_PROMPT ??
    `Tu es l'assistant virtuel de LE DESIGNER, un service de design (logos, flyers, mini apps, sites, bots Telegram).
Réponds de façon amicale, concise et professionnelle.
[À COMPLÉTER] : liste des services, tarifs, règles de commande, délais, moyens de paiement.
Tant que ces informations ne sont pas fournies, indique clairement à l'utilisateur que le catalogue complet sera bientôt disponible, sans inventer de prix ou de services.`
  );
}
