"use client";

/**
 * Wrapper léger autour du SDK Telegram WebApp (window.Telegram.WebApp).
 * Le script officiel doit être chargé via <Script src="https://telegram.org/js/telegram-web-app.js" />
 * (voir app/layout.tsx).
 */

declare global {
  interface Window {
    Telegram?: {
      WebApp: {
        initData: string;
        initDataUnsafe: {
          user?: {
            id: number;
            first_name: string;
            last_name?: string;
            username?: string;
            photo_url?: string;
            language_code?: string;
          };
        };
        ready: () => void;
        expand: () => void;
        close: () => void;
        BackButton: {
          show: () => void;
          hide: () => void;
          onClick: (cb: () => void) => void;
          offClick: (cb: () => void) => void;
        };
        MainButton: {
          text: string;
          show: () => void;
          hide: () => void;
          onClick: (cb: () => void) => void;
          setParams: (params: Record<string, unknown>) => void;
        };
        HapticFeedback: {
          impactOccurred: (style: "light" | "medium" | "heavy") => void;
          notificationOccurred: (type: "error" | "success" | "warning") => void;
        };
        colorScheme: "light" | "dark";
        themeParams: Record<string, string>;
      };
    };
  }
}

export function getTelegramWebApp() {
  if (typeof window === "undefined") return null;
  return window.Telegram?.WebApp ?? null;
}

/** initData brute à envoyer dans le header x-telegram-init-data de chaque appel API */
export function getInitData(): string {
  return getTelegramWebApp()?.initData ?? "";
}

/**
 * fetch() wrapper qui attache automatiquement l'initData Telegram.
 * Utiliser CE helper pour tout appel vers /api/** qui nécessite l'identité utilisateur.
 */
export async function apiFetch(input: string, init: RequestInit = {}) {
  const initData = getInitData();
  return fetch(input, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      "x-telegram-init-data": initData,
      ...(init.headers ?? {}),
    },
  });
}
