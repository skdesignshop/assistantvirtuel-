"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { getTelegramWebApp } from "@/lib/telegram-client";

/**
 * Branche le BackButton natif de Telegram (celui intégré à l'UI de Telegram,
 * pas un bouton HTML) sur la navigation Next.js. À utiliser sur toute page
 * qui n'est pas la racine de la navigation (accueil / onglets principaux).
 *
 * Exemple: useTelegramBackButton(() => router.push("/accueil"))
 */
export function useTelegramBackButton(onBack: () => void, enabled = true) {
  useEffect(() => {
    const tg = getTelegramWebApp();
    if (!tg || !enabled) return;

    const handler = () => onBack();
    tg.BackButton.show();
    tg.BackButton.onClick(handler);

    return () => {
      tg.BackButton.offClick(handler);
      tg.BackButton.hide();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [enabled]);
}

/** Cache le bouton retour natif (pour les pages racines: accueil, onglets principaux) */
export function useHideTelegramBackButton() {
  useEffect(() => {
    const tg = getTelegramWebApp();
    tg?.BackButton.hide();
  }, []);
}
