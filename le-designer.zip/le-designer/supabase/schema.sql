-- ============================================================================
-- LE DESIGNER — Schéma Supabase complet
-- À exécuter dans Supabase SQL Editor (Database > SQL Editor > New query)
-- ============================================================================

create extension if not exists "pgcrypto";

-- ============================================================================
-- TABLE: users
-- ============================================================================
create table if not exists public.users (
  id uuid primary key default gen_random_uuid(),
  telegram_id bigint unique not null,
  first_name text not null,
  last_name text,
  username text,
  photo_url text,
  city text,
  created_at timestamptz not null default now(),
  last_seen_at timestamptz not null default now(),
  visit_count integer not null default 1,
  order_count integer not null default 0,
  loyalty_progress integer not null default 0 check (loyalty_progress >= 0 and loyalty_progress <= 10),
  is_admin boolean not null default false
);

create index if not exists idx_users_telegram_id on public.users (telegram_id);
create index if not exists idx_users_city on public.users (city);
create index if not exists idx_users_last_seen on public.users (last_seen_at desc);

-- ============================================================================
-- TABLE: loyalty_codes
-- ============================================================================
create table if not exists public.loyalty_codes (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,
  used boolean not null default false,
  used_by uuid references public.users (id) on delete set null,
  used_at timestamptz,
  created_at timestamptz not null default now(),
  created_by bigint not null -- telegram_id de l'admin qui a généré le code
);

create index if not exists idx_loyalty_codes_code on public.loyalty_codes (code);
create index if not exists idx_loyalty_codes_used on public.loyalty_codes (used);

-- ============================================================================
-- TABLE: testimonials
-- ============================================================================
create table if not exists public.testimonials (
  id uuid primary key default gen_random_uuid(),
  telegram_user_id bigint,
  name text not null,
  photo_url text,
  city text,
  message text not null,
  rating smallint check (rating between 1 and 5),
  visible boolean not null default true,
  created_at timestamptz not null default now()
);

create index if not exists idx_testimonials_visible on public.testimonials (visible);

-- ============================================================================
-- TABLE: cities
-- ============================================================================
create table if not exists public.cities (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  country text not null default 'France',
  latitude double precision not null,
  longitude double precision not null,
  logo_url text,
  image_url text,
  description text,
  link text,
  visible boolean not null default true,
  created_at timestamptz not null default now()
);

create index if not exists idx_cities_visible on public.cities (visible);

-- ============================================================================
-- TABLE: messages (historique conversation assistant)
-- ============================================================================
create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  telegram_user_id bigint not null,
  role text not null check (role in ('user', 'assistant', 'system')),
  content text not null,
  created_at timestamptz not null default now()
);

create index if not exists idx_messages_telegram_user_id on public.messages (telegram_user_id, created_at);

-- ============================================================================
-- TABLE: app_events (analytics)
-- ============================================================================
create table if not exists public.app_events (
  id uuid primary key default gen_random_uuid(),
  telegram_user_id bigint,
  event_type text not null,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists idx_app_events_type on public.app_events (event_type, created_at);
create index if not exists idx_app_events_user on public.app_events (telegram_user_id, created_at);

-- ============================================================================
-- ROW LEVEL SECURITY
-- Tout passe par le backend avec la clé service_role (qui bypass RLS).
-- Le frontend n'utilise JAMAIS la clé service_role, uniquement des appels
-- vers nos propres routes API (/app/api/**), qui valident tout côté serveur.
-- On active quand même RLS partout et on ne crée AUCUNE policy publique,
-- ce qui bloque par défaut tout accès direct depuis le frontend (anon key).
-- ============================================================================

alter table public.users enable row level security;
alter table public.loyalty_codes enable row level security;
alter table public.testimonials enable row level security;
alter table public.cities enable row level security;
alter table public.messages enable row level security;
alter table public.app_events enable row level security;

-- Seule exception "publique" utile : lecture des villes/avis visibles
-- directement via la clé anon, si un jour le frontend veut lire Supabase
-- en direct (optionnel — actuellement tout passe par nos API routes).
create policy "Public read visible cities" on public.cities
  for select using (visible = true);

create policy "Public read visible testimonials" on public.testimonials
  for select using (visible = true);

-- Aucune autre policy : insert/update/delete impossibles depuis le frontend,
-- même sur cities/testimonials. Seule la clé service_role (backend) peut écrire.

-- ============================================================================
-- FONCTION: consommer un code de fidélité de façon atomique
-- Empêche la double-utilisation simultanée d'un même code (race condition)
-- ============================================================================
create or replace function public.redeem_loyalty_code(
  p_code text,
  p_user_id uuid
) returns jsonb
language plpgsql
security definer
as $$
declare
  v_code_row public.loyalty_codes%rowtype;
  v_user_row public.users%rowtype;
begin
  -- Verrouille la ligne du code pour éviter toute utilisation concurrente
  select * into v_code_row
  from public.loyalty_codes
  where code = p_code
  for update;

  if not found then
    return jsonb_build_object('success', false, 'error', 'code_not_found');
  end if;

  if v_code_row.used then
    return jsonb_build_object('success', false, 'error', 'code_already_used');
  end if;

  update public.loyalty_codes
  set used = true, used_by = p_user_id, used_at = now()
  where id = v_code_row.id;

  update public.users
  set
    order_count = order_count + 1,
    loyalty_progress = least(loyalty_progress + 1, 10)
  where id = p_user_id
  returning * into v_user_row;

  return jsonb_build_object(
    'success', true,
    'loyalty_progress', v_user_row.loyalty_progress,
    'order_count', v_user_row.order_count,
    'gift_unlocked', v_user_row.loyalty_progress = 10
  );
end;
$$;

-- ============================================================================
-- Données de démo (à supprimer / remplacer plus tard)
-- ============================================================================
insert into public.cities (name, country, latitude, longitude, visible, description)
values
  ('Paris', 'France', 48.8566, 2.3522, true, 'Ville de démonstration — à remplacer'),
  ('Lyon', 'France', 45.7640, 4.8357, true, 'Ville de démonstration — à remplacer'),
  ('Marseille', 'France', 43.2965, 5.3698, true, 'Ville de démonstration — à remplacer')
on conflict do nothing;
