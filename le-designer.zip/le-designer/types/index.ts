export interface AppUser {
  id: string;
  telegram_id: number;
  first_name: string;
  last_name: string | null;
  username: string | null;
  photo_url: string | null;
  city: string | null;
  created_at: string;
  last_seen_at: string;
  visit_count: number;
  order_count: number;
  loyalty_progress: number;
  is_admin: boolean;
}

export interface LoyaltyCode {
  id: string;
  code: string;
  used: boolean;
  used_by: string | null;
  used_at: string | null;
  created_at: string;
  created_by: number;
}

export interface Testimonial {
  id: string;
  telegram_user_id: number | null;
  name: string;
  photo_url: string | null;
  city: string | null;
  message: string;
  rating: number | null;
  visible: boolean;
  created_at: string;
}

export interface City {
  id: string;
  name: string;
  country: string;
  latitude: number;
  longitude: number;
  logo_url: string | null;
  image_url: string | null;
  description: string | null;
  link: string | null;
  visible: boolean;
  created_at: string;
}

export interface AssistantMessage {
  id: string;
  telegram_user_id: number;
  role: "user" | "assistant" | "system";
  content: string;
  created_at: string;
}

export interface AppEvent {
  id: string;
  telegram_user_id: number | null;
  event_type: AppEventType;
  metadata: Record<string, unknown>;
  created_at: string;
}

export type AppEventType =
  | "app_open"
  | "first_visit"
  | "page_view"
  | "assistant_open"
  | "message_sent"
  | "loyalty_open"
  | "loyalty_code_attempt"
  | "loyalty_code_success"
  | "loyalty_completed"
  | "city_view"
  | "testimonial_view";

export interface AdminStats {
  users: {
    total: number;
    new_last_7_days: number;
    active_today: number;
    active_this_week: number;
    active_this_month: number;
  };
  activity: {
    total_visits: number;
    total_conversations: number;
    total_messages: number;
    total_orders: number;
    loyalty_completed: number;
    gifts_unlocked: number;
  };
  loyalty: {
    codes_generated: number;
    codes_used: number;
    codes_available: number;
    users_started: number;
    users_completed: number;
  };
  cities: {
    users_per_city: { city: string; count: number }[];
    most_active_cities: { city: string; count: number }[];
  };
  testimonials: {
    total: number;
    visible: number;
    hidden: number;
  };
}
